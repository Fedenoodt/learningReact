import Products from "../Components/Products.jsx"
import Details from "../Components/Details.jsx"

function Home () {
    return <>
        <div>
            
        </div>
    </>
}

export default Home