import Products from "../Components/Products.jsx"

function Home () {
    return <>
        <div>
            <Products />
        </div>
    </>
}

export default Home