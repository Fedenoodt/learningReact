import { Link } from "react-router-dom";
import Products from "../Components/Products.jsx"

function Home () {
    <Products />
    return <div>
        <div>
          <br />
          <button><Link to='/login'>Ingresar</Link></button>
          <button><Link to='/register'>Registrarse</Link></button>
          
          </div>
  </div>
}

export default Home