import React, { Component } from "react";
import Fields from './Field.jsx'

class Forms extends Component {
    render () {
        return(
        <form action="" method="">
            <Fields/>
        </form>
        );
}
}

export default Forms