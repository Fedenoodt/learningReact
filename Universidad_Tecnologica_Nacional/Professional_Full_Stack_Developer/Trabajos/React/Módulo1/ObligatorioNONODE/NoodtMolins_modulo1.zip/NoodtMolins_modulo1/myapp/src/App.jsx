import { useState } from 'react'
import './App.css'
import Forms from './Form.jsx'

function App() {

  return (
    <>
          <Forms/>
    </>
  )
}

export default App
