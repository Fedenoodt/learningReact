Abrir el archivo con vista previa desde la opción haciendo clic secundario en el readme.

### `Resolución Trabajo práctico Extra - Tablero de Basquet (optativo)`

Les dejo adjunto los screen con una forma de resolver el ejercicio.

### Componente `Equipo.jsx`

![Prev](/resolucion/img/res_equipo.png)

### Componente `Tablero.jsx`

![Prev](/resolucion/img/res_tablero.png)

### Funciones

![Prev](/resolucion/img/res_functions.png)
