function IsoLogo () {
    return <> <div className="absoluteBox"><nav className="isoLogo">
        <h1>Mercado Trucho</h1>
    </nav>
    </div><div className="static"></div></>
}

export default IsoLogo